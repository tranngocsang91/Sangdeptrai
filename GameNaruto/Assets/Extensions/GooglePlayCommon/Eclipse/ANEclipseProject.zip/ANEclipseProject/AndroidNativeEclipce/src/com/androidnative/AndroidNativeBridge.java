package com.androidnative;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.androidnative.billing.core.BillingManager;
import com.androidnative.features.AppInfoLoader;
import com.androidnative.features.CameraAPI;
import com.androidnative.features.common.AddressBookManager;
import com.androidnative.features.common.AndroidNativeUtility;
import com.androidnative.features.social.instagram.AnInstagram;
import com.androidnative.features.social.twitter.ANTwitter;
import com.androidnative.gms.analytics.V4GoogleAnalytics;
import com.androidnative.gms.core.GameClientManager;
import com.androidnative.utils.Base64;
import com.androidnative.utils.Base64DecoderException;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

@SuppressLint("NewApi")
public class AndroidNativeBridge extends UnityPlayerActivity {

	private static AndroidNativeBridge inst = null;

	

	/**
	 * Tag used on log messages.
	 */
	public static final String TAG = "AndroidNative";
	

	public static final String ANDROID_APP_EVENT_LISTNER = "AndroidApp";
	
	/**
	 * Splitters.
	 */
	public static final String UNITY_SPLITTER = "|";
	public static final String UNITY_EOF = "endofline";
	


	private FileOutputStream fos;

	

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		inst = this;

	}

	public static AndroidNativeBridge GetInstance() {
		return inst;
	}

	// --------------------------------------
	// Override
	// --------------------------------------

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		//native api
		try {
			try {
				UnityPlayer.UnitySendMessage(ANDROID_APP_EVENT_LISTNER, "onActivityResult", String.valueOf(requestCode) + AndroidNativeBridge.UNITY_SPLITTER + String.valueOf(resultCode));
				CameraAPI.GetInstance().onActivityResult(requestCode, resultCode, data);

			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative onActivityResult NoClassDefFoundError", ex.getMessage());
		}
		
		//billing
		try {
			try {

				BillingManager.GetInstance().handleActivityResult(requestCode, resultCode, data);

			} catch (Exception ex) {
				Log.d("AndroidNative", "Error, Billing disabled: " + ex.getMessage());
				ex.printStackTrace();
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative onActivityResult NoClassDefFoundError", ex.getMessage());
		}
		
		//google play
		try {
			try {
				if (GameClientManager.isStarted()) {
					
					Handler handler = new Handler();
					final int arRequest = requestCode;
					final int arResult = resultCode;
					final Intent arData = data;
					// delay between sending result, since unity will report un-pause only in next frame
					handler.postDelayed(new Runnable() {
					            public void run() {
					            	GameClientManager.GetInstance().onActivityResult(arRequest, arResult, arData);
					            }
					        }, 1000);
					
					
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative onActivityResult NoClassDefFoundError", ex.getMessage());
		}
		
		super.onActivityResult(requestCode, resultCode, data);

	}

	@Override
	public void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		
		Log.d("AndroidNative", "onNewIntent: ");
		UnityPlayer.UnitySendMessage(ANDROID_APP_EVENT_LISTNER, "onNewIntent", "");

		
		//twitter
		try {
			try {
				
				ANTwitter.GetInstance().SetIntent(intent);
			} catch (Throwable ex) {
				Log.d("AndroidNative", "onNewIntent has failed");
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onNewIntent NoClassDefFoundError" + ex.getMessage());
		}
		
		
		
		
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		try {
			BillingManager.GetInstance().dispose();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onDestroy: " + ex.getMessage());
		}
	}


	// --------------------------------------
	// Internal API
	// --------------------------------------

	// --------------------------------------
	// Google Cloud
	// --------------------------------------

	public void listStates() {
		try {
			GameClientManager.GetInstance().listStates();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError listStates: " + ex.getMessage());
		}
		
	}

	public void updateState(String stateKey, String data) {
		try {
			GameClientManager.GetInstance().updateState(Integer.parseInt(stateKey), data);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError updateState: " + ex.getMessage());
		}
		
	}

	public void deleteState(String stateKey) {
		try {
			GameClientManager.GetInstance().deleteState(Integer.parseInt(stateKey));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError deleteState: " + ex.getMessage());
		}
		
	}

	public void loadState(String stateKey) {
		try {
			GameClientManager.GetInstance().loadState(Integer.parseInt(stateKey));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadState: " + ex.getMessage());
		}
		
	}

	public void resolveState(String stateKey, String resolvedData,String resolvedVersion) {
		try {
			GameClientManager.GetInstance().resolveState(Integer.parseInt(stateKey),
					resolvedData, resolvedVersion);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resolveState: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// BILLING
	// --------------------------------------

	public void connectToBilling(String ids, String base64EncodedPublicKey) {
		try {
			
			BillingManager.GetInstance().SetActivity(this);

			ArrayList<String> products = new ArrayList<String>();
			String[] result = ids.split(",");

			for (String id : result) {
				products.add(id);
			}

			BillingManager.GetInstance().connect(products, base64EncodedPublicKey);
			
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void retrieveProducDetails() {
		try {
			BillingManager.GetInstance().retrieveProducDetails();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void consume(String SKU) {
		try {
			BillingManager.GetInstance().consume(SKU);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void purchase(String SKU, String developerPayload) {
		try {
			BillingManager.GetInstance().purchase(SKU, developerPayload);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void subscribe(String SKU, String developerPayload) {
		try {
			BillingManager.GetInstance().subscribe(SKU, developerPayload);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}



	// --------------------------------------
	// OTHER FEATURES
	// --------------------------------------

	public void loadAddressBook() {
		AddressBookManager.GetInstance().load();
	}

	public void LoadPackageInfo() {
		AppInfoLoader.LoadPackageInfo();
	}

	// --------------------------------------
	// Analytics
	// --------------------------------------

	public void startAnalyticsTracking() {
		try {
			try {
				
				V4GoogleAnalytics.GetInstance().startAnalyticsTracking(this);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError startAnalyticsTracking: " + ex.getMessage());
		}
		
	}

	public void SetTrackerID(String trackingID) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().SetTracker(trackingID);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SetTrackerID: " + ex.getMessage());
		}
		
		
	}

	public void SendView(String appScreen) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().SendView(appScreen);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendView: " + ex.getMessage());
		}
		
	}

	public void SendView() {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().SendView();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendView: " + ex.getMessage());
		}
		
	}

	public void SendEvent(String category, String action, String label, String value) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().sendEvent(category, action, label,
						value);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendEvent: " + ex.getMessage());
		}
		
		
	}

	public void SendEvent(String category, String action, String label,String value, String key, String val) {

		try {
			try {
				V4GoogleAnalytics.GetInstance().sendEvent(category, action, label, 	value, key, val);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendEvent: " + ex.getMessage());
		}
		
	}

	public void SetKey(String key, String value) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().setKey(key, value);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SetKey: " + ex.getMessage());
		}
		
	}

	public void ClearKey(String key) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().clearKey(key);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError ClearKey: " + ex.getMessage());
		}
		
	}

	public void SendTiming(String category, String intervalInMilliseconds,String name, String label) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().sendTiming(category,
						intervalInMilliseconds, name, label);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendTiming: " + ex.getMessage());
		}
		
		
	}

	public void CreateTransaction(String transactionId, String affiliation, String revenue, String tax, String shipping, String currencyCode) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().CreateTransaction(transactionId,
						affiliation, revenue, tax, shipping, currencyCode);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError CreateTransaction: " + ex.getMessage());
		}
		
		
	}

	public void CreateItem(String transactionId, String name, String sku,String category, String price, String quantity, String currencyCode) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().CreateItem(transactionId, name, sku,
						category, price, quantity, currencyCode);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError CreateItem: " + ex.getMessage());
		}
		
		
	}

	public void SetLogLevel(String lvl) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().SetLogLevel(Integer.parseInt(lvl));
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SetLogLevel: " + ex.getMessage());
		}
		
		
	}

	public void SetDryRun(String mode) {
		
		try {
			try {
				boolean m = false;
				if (mode.equals("true")) {
					m = true;
				} else {
					m = false;
				}
				
				V4GoogleAnalytics.GetInstance().setDryRun(m);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "SetDryRun SetLogLevel: " + ex.getMessage());
		}
		
	}
	
	public void enableAdvertisingIdCollection(String mode) {
		try {
			try {
				boolean m = false;
				if (mode.equals("true")) {
					m = true;
				} else {
					m = false;
				}
				
				V4GoogleAnalytics.GetInstance().enableAdvertisingIdCollection(m);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "SetDryRun SetLogLevel: " + ex.getMessage());
		}
		
	}
	
	// --------------------------------------
	// Twitter
	// --------------------------------------

	public void TwitterInit(String consumer_key, String consumer_secret) {
		try {
			ANTwitter.GetInstance().Init(consumer_key, consumer_secret, this);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError TwitterInit: " + ex.getMessage());
		}
		
	}

	public void AuthificateUser() {
		try {
			ANTwitter.GetInstance().AuthificateUser();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError AuthificateUser: " + ex.getMessage());
		}
		
	}

	public void LoadUserData() {
		try {
			ANTwitter.GetInstance().LoadUserData();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError LoadUserData: " + ex.getMessage());
		}
		
	}

	public void TwitterPost(String status) {
		try {
			ANTwitter.GetInstance().Twitt(status);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError ANTwitter.GetInstance().Twitt(status);: " + ex.getMessage());
		}
		
	}

	public void TwitterPostWithImage(String status, String data) throws IOException, Base64DecoderException {
		
		try {
			Log.d("AndroidNative", "TwitterPostWithImage: ");
			byte[] byteArray = Base64.decode(data);

			File tempFile;
			tempFile = new File(this.getCacheDir(), "twitter_post_image");
			fos = new FileOutputStream(tempFile);
			fos.write(byteArray);

			ANTwitter.GetInstance().Twitt(status, tempFile);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError TwitterPostWithImage: " + ex.getMessage());
		}
		

	}

	public void LogoutFromTwitter() {
		try {
			ANTwitter.GetInstance().logoutFromTwitter();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError LogoutFromTwitter: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// Instagram
	// --------------------------------------

	public void InstagramPostImage(String data, String caption) {
		try {
			AnInstagram.Share(data, caption);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError InstagramPostImage: " + ex.getMessage());
		}
		
	}

	
	// --------------------------------------
	// Utils
	// --------------------------------------
	
	public void isPackageInstalled(String packagename) {
		try {
			try {
				AndroidNativeUtility.GetInstance().isPackageInstalled(packagename);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError isPackageInstalled: " + ex.getMessage());
		}
		
	}
	
	public void runPackage(String packagename) {
		try {
			try {
				AndroidNativeUtility.GetInstance().runPackage(packagename);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError runPackage: " + ex.getMessage());
		}

	}
	
	
	public void SaveToGalalry(String ImageData, String name) {
		try {
			try {
				CameraAPI.GetInstance().SaveToGalalry(ImageData, name);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SaveToGalalry: " + ex.getMessage());
		}
		
	}
	
	
	public void InitCameraAPI(String folderName, String maxSize, String mode) {
		try {
			try {
				CameraAPI.GetInstance().Init(folderName, Integer.parseInt(maxSize) , Integer.parseInt(mode));
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError InitCameraAPI: " + ex.getMessage());
		}
		
		
		
	}
	


	public void GetImageFromGallery() {
		try {
			try {
				CameraAPI.GetInstance().GetImageFromGallery();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GetImageFromGallery: " + ex.getMessage());
		}
		
	}
	
	
	
	public void GetImageFromCamera() {
		
		try {
			try {
				CameraAPI.GetInstance().GetImageFromCamera();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GetImageFromCamera: " + ex.getMessage());
		}
			
	}
	
}
