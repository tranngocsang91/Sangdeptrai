package com.androidnative.gms.listeners.appstate;

import java.util.Iterator;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.appstate.AppState;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.appstate.AppStateManager.StateListResult;
import com.google.android.gms.common.api.ResultCallback;
import com.unity3d.player.UnityPlayer;

public class StatesLoadedListener implements ResultCallback<AppStateManager.StateListResult> {

	@Override
	public void onResult(StateListResult arg0) {
		// TODO Auto-generated method stub
		
		
		Log.d("AndroidNative", "listStates Status: " + arg0.getStatus().getStatusCode());
		Log.d("AndroidNative", "listStates Count: "  + arg0.getStateBuffer().getCount());

		StringBuilder result = new StringBuilder();
		result.append(arg0.getStatus().getStatusCode());

		// TODO Auto-generated method stub
		Iterator<AppState> iterator = arg0.getStateBuffer().iterator();

		// boolean first = true;
		while (iterator.hasNext()) {

			AppState st = iterator.next();
			String data = GameClientManager.ConvertCloudDataToString(st.getLocalData());

			result.append(GameClientManager.UNITY_SPLITTER);
			result.append(st.getKey());
			result.append(GameClientManager.UNITY_SPLITTER);
			result.append(data);

			Log.d("AndroidNative", "State Data: " + data);

		}

		if (arg0.getStateBuffer().getCount() > 0) {
			result.append(GameClientManager.UNITY_EOF);
		}
		
		arg0.getStateBuffer().close();

		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_CLOUD_LISTNER_NAME,
				"OnAllStatesLoaded", result.toString());
	}

}
