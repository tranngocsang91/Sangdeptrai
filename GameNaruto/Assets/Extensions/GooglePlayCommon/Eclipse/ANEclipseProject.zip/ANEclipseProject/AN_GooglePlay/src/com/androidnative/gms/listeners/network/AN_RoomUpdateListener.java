package com.androidnative.gms.listeners.network;

import android.util.Log;

import com.androidnative.gms.network.RealTimeMultiplayerController;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.unity3d.player.UnityPlayer;

public class AN_RoomUpdateListener implements RoomUpdateListener {


	@Override
	public void onJoinedRoom(int statusCode, Room room) {
		
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			RealTimeMultiplayerController.GetInstance().OnRoomUpdated(room);
		}
		
		Log.d(GameClientManager.TAG, "onJoinedRoom size: " + room.getParticipants().size());
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnJoinedRoom", String.valueOf(statusCode));
		
	}

	@Override
	public void onLeftRoom(int statusCode, String roomid) {
		Log.d(GameClientManager.TAG, "onLeftRoom");
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnLeftRoom", String.valueOf(statusCode) + GameClientManager.UNITY_SPLITTER + roomid);
		
	}

	@Override
	public void onRoomConnected(int statusCode, Room room) {
		Log.d(GameClientManager.TAG, "onRoomConnected");
		//Log.d(AndroidNativeBridge.TAG, "ON ROOM CONNECTED (" + statusCode + ", " + room + ")");
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			RealTimeMultiplayerController.GetInstance().OnRoomUpdated(room);
		}
		

		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnRoomConnected", String.valueOf(statusCode));
		
	}

	@Override
	public void onRoomCreated(int statusCode, Room room) {
		Log.d(GameClientManager.TAG, "onRoomCreated: " + statusCode);
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			RealTimeMultiplayerController.GetInstance().OnRoomUpdated(room);
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnRoomCreated", String.valueOf(statusCode));
	
	}

}
