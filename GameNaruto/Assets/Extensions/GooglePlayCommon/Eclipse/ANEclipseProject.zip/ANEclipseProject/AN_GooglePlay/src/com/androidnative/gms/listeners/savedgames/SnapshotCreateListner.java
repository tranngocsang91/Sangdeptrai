package com.androidnative.gms.listeners.savedgames;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.utils.Base64;
import com.androidnative.gms.utils.Base64DecoderException;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.SnapshotMetadataChange;
import com.google.android.gms.games.snapshot.Snapshots.OpenSnapshotResult;
import com.unity3d.player.UnityPlayer;

public class SnapshotCreateListner implements ResultCallback<OpenSnapshotResult> {
	
	String _name;
	String _description;
	String _ImageData;
	String _Data;
	long _PlayedTime;

	public SnapshotCreateListner(String name, String description, String ImageData, String Data, long PlayedTime) {
		_name = name;
		_description = description;
		_ImageData = ImageData;
		_Data = Data;
		_PlayedTime = PlayedTime;
	}
	
	
	
	@Override
	public void onResult(OpenSnapshotResult result) {
		 Snapshot snapshot = result.getSnapshot();
		 
		 if(snapshot != null) {
			    byte[] byteArray;
				try {
					
					byteArray = Base64.decode(_ImageData);
					Bitmap bmp;
					bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
					

					snapshot.writeBytes(Base64.decode(_Data));

			        // Save the snapshot.
					SnapshotMetadataChange.Builder builder =  new SnapshotMetadataChange.Builder();
					builder.setCoverImage(bmp).setDescription(_description);
					if(_PlayedTime != 0) {
						builder.setPlayedTimeMillis(_PlayedTime);
					}
					
			        SnapshotMetadataChange metadataChange = builder.build();
			               
			            
			        Games.Snapshots.commitAndClose(GameClientManager.GetInstance().API(), snapshot, metadataChange).setResultCallback(new SnapshotMetadataChangeListner());
			        
				} catch (Base64DecoderException e) {
					e.printStackTrace();
					Log.d("AndroidNative", "Failed to save snapshot: " + e.getMessage());
					
					StringBuilder  builder = new StringBuilder();
					builder.append(GamesStatusCodes.STATUS_INTERNAL_ERROR);
					UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnSavedGameSaveResult", builder.toString());
				}
				
		 } else {
			int status = result.getStatus().getStatusCode();
			StringBuilder  builder = new StringBuilder();
			builder.append(status);
			UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnSavedGameSaveResult", builder.toString());
		 }
	}
	


}
