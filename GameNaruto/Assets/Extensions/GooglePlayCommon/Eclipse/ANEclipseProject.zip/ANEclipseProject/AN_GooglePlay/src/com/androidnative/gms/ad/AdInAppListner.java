package com.androidnative.gms.ad;

import com.google.android.gms.ads.purchase.InAppPurchase;
import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.unity3d.player.UnityPlayer;

public class AdInAppListner implements InAppPurchaseListener{
	
	public static InAppPurchase purchaseRequest = null;

	@Override
	public void onInAppPurchaseRequested(InAppPurchase inAppPurchase) {
		purchaseRequest = inAppPurchase;
		
		UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnInAppPurchaseRequested", purchaseRequest.getProductId());
	}
	
	public static void RecordAdInAppPurchasResolution(int resolution) {
		if(purchaseRequest != null) {
			purchaseRequest.recordResolution(resolution);
			purchaseRequest = null;
		}
	}
	
}
